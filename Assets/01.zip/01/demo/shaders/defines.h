
#define MC_MODE 1
 // 0 = intermediate buffer stores CELLS to generate
 // 1 = intermediate buffer stores TRIANGLES to generate