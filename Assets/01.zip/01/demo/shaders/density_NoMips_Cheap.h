#define EVAL_NO_MIPS
#define EVAL_CHEAP
#include "density.h"